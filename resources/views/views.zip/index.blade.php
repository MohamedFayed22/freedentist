@extends('frontend.app')

@section('content')
<!-- Main Content-->

    <main class="main-content">
      <div class="home-back"></div>
      <!--banner section-->
      <!--modal-->
      <div class="modal" id="myModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button class="close" type="button" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
              <div class="days">
                <ul class="nav nav-pills nav-justified">
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day1">1</a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day2">2</a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day3">3</a></li>
                  <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#day4">4</a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day5">5</a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day6">6</a></li>
                  <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#day7">7</a></li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane" role="tabpanel" id="day1">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane" role="tabpanel" id="day2">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane" role="tabpanel" id="day3">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane active" role="tabpanel" id="day4">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane" role="tabpanel" id="day5">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane" role="tabpanel" id="day6">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                  <div class="tab-pane" role="tabpanel" id="day7">
                    <div class="time-available"><span>8:30</span></div>
                    <div class="time-notAvailable"><span>9:30</span></div>
                    <div class="time-available"><span>10:30</span></div>
                    <div class="time-available"><span>11:30</span></div>
                    <div class="time-available"><span>12:30</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="home-content">
        <div class="container">
          <div class="bannerContent">
            <h1>@lang('home.featureText1')</h1>
            <h3>@lang('home.featureText2').</h3>
          </div>
          <div class="bannerRow">
			 <form method="GET" action="{{ route('searchReservation') }}" enctype="multipart/form-data">
            <div class="row">
                        @csrf
              <div class="col-md-3 padd0">
                <select class="form-control selectdd" required name="city" id="city_id">
                  <option class="locate" selected disabled data-image="assets/imgs/home/location.svg">@lang('home.city')  </option>
                     @foreach($cities as $city)
                                                        <option  value="{{$city->id}}">@if( app()->getLocale()=='ar')
					{{$city->city_name_ar}}
					@elseif( app()->getLocale()=='en')
					{{$city->city_name_en}}
					@endif</option>
                                                    @endforeach
                </select>
              </div>
              <div class="col-md-3 padd0">
                <select class="form-control selectdd" name="hospital_id" id="hospital_id" required>
                  <option class="locate" selected disabled data-image="assets/imgs/home/location.svg">@lang('home.center')</option>
                  
                </select>
              </div>
              <div class="col-md-3 padd0">
                
                  <select class="form-control selectdd" name="service_id" id="service_id" required="required">
                  <option class="locate" selected disabled data-image="assets/imgs/home/doctor.svg">@lang('home.service')</option>  
				    @foreach($services as $service)
                                                        <option {{(old('service_id') == $service->id)?'selected="selected"':""}} value="{{$service->id}}">@if( app()->getLocale()=='ar')
					{{$service->service_name_ar}}
					@elseif( app()->getLocale()=='en')
					{{$service->service_name_en}}
					@endif</option>
                                                    @endforeach
                                                    
                                                </select>

              </div>
              <div class="col-md-2 padd0">
                <div class="input-group date" id="datetimepicker1" data-target-input="nearest">
                  <div class="input-group-append" data-target="#datetimepicker1" data-toggle="datetimepicker">
                    <div class="input-group-text"><img src="assets/imgs/home/calender.svg"></div>
                  </div>
                  <input class="form-control datetimepicker-input" type="text" data-target="#datetimepicker1" name="date" placeholder="@lang('home.time')">
                </div>
              </div>
              <div class="col-md-1 padd0">
                
				 <button type="submit" class="btn-banner">
                                  @lang('home.save')
                                </button>
			   </form>
              </div>
            </div>
          </div>
          <div class="stepsRow">
            <div class="squareStart"></div>
            <div class="row">
              <div class="col-md-3">
                <div class="step step1"><img src="assets/imgs/home/location2.svg">
                  <div class="stepSquare"></div>
                  <h4>@lang('home.feature1')</h4>
                </div>
              </div>
              <div class="col-md-3">
                <div class="step step2">
                  <div class="stepSquare"></div><img src="assets/imgs/home/doctor2.svg">
                  <h4>@lang('home.feature2')</h4>
                </div>
              </div>
              <div class="col-md-3">
                <div class="step step1"><img src="assets/imgs/home/calender2.svg">
                  <div class="stepSquare"></div>
                  <h4>@lang('home.feature3')</h4>
                </div>
              </div>
              <div class="col-md-3">
                <div class="step step2">
                  <div class="stepSquare"></div><img src="assets/imgs/home/teeth.svg">
                  <h4>@lang('home.feature4')</h4>
                </div>
              </div>
            </div>
            <div class="squareEnd"></div>
          </div>
        </div>
      </div>
    </main>
    <!-- End Main Content-->
@endsection
@section('script')
 <script>

       $('#city_id').on('change', function(event) {
		 
            var city_id = $(this).val();
//alert(city_id);

            var token = $("input[name='_token']").val();

            $.ajax({

                url: "<?php echo route('select-hospital') ?>",

                method: 'POST',

                data: {city_id:city_id, _token:token},

                success: function(data) {

                    $("select[name='hospital_id']").html('');

                    $("select[name='hospital_id']").html(data.options);
//alert(data.options);
                }

            });

        });
		 
    </script>
@endsection
