@extends('frontend.app')

@section('content')
<main class="main-content">
      <!--dateDetails section-->
      <section class="dateDetails"> 
        <div class="title">
          <div class="container">
            <h2>تفاصيل الموعد </h2>
          </div>
        </div>
        <div class="container">
          <div class="content">
            <div class="date-det">
              <h5 class="grey3">رقم الموعد</h5>
              <h4 class="blue2">#{{  $object[0]->event_id }}</h4>
            </div>
            <div class="date-det">
              <h5 class="grey3">أسم المراجع</h5>
              <h4 class="blue2">
			  @if($follower)
			  	{{ $follower[0]->name}}
				 @else
				{{ $object[0]->Uname }}
			  @endif
			  </h4>
            </div>
            <div class="date-det">
              <h5 class="grey3">أسم المستشفى</h5>
              <h4 class="blue2">{{  $object[0]->hospital_name_ar }}</h4>
            </div>
			@if(isset(Auth::guard('dentist')->user()->id))
            <!--<div class="date-det">
              <h5 class="grey3">الطبيب المعالج</h5>
              <h4 class="blue2">{{$object[0]->D_name}}</h4>
            </div>-->
			@endif
            <div class="date-det">
              <h5 class="grey3">العلاج المطلوب</h5>
              <h4 class="blue2">{{  $object[0]->service_name_ar }}</h4>
            </div>
            <div class="date-det">
              <h5 class="grey3"> الوقت و التاريخ</h5>
              <h4 class="blue2">{{  $object[0]->start_time }} السبت {{  $object[0]->event_date }}</h4>
            </div>
            <div class="date-det">
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input" type="checkbox" id="alarm" name="alarmCheck">
                <label class="custom-control-label blue" for="alarm">تفعيل التنبية</label>
              </div>
            </div>
            <div class="date-det">
              <h5 class="grey3">الحالة</h5>
			  @if($object[0]->status=="0")
			   <h4 class="blue2">في الانتظار الموافقه خلال 6 ساعات كحد اقصى</h4>
			   @elseif($object[0]->status=="1")
			   <h4 class="blue2">تمت الموافقة</h4>
			   @elseif($object[0]->status=="3")
			   <h4 class="pink">رفض</h4>
			   <div class="date-det">
              <h5 class="grey3">سبب الرفض</h5>
              <h4 class="pink">{{$object[0]->reason}}</h4>
            </div>
			  @endif
             
            </div>
            
            
            <div class="date-det">
              <h5 class="grey3">المرفقات</h5>
              <div class="attach-image">
			  @if(!empty($object[0]->photo))
			  <img src="{{url('images/'.$object[0]->photo)}}">
			  @else
			  لايوجد
			  @endif
			  
			 
			 </div>
            </div>
			@if(isset(Auth::guard('dentist')->user()->id))
            <?php 
			$today=date('Y-m-d');
			if( $object[0]->event_date >= $today){?>
				
			 <div class="btns">
              <a href="{{ route('accepetReservation', $object[0]->event_id)  }}" class="navBtn">تأكيد الحجز</a>
              <a href="{{ route('neglectReservation', $object[0]->event_id)  }}" class="w-btn">الغاء الحجز </a>
            <!--  <button class="w-btn">الغاء الحجز</button>-->
            </div>
		<?php	}
			?>
           @endif
          </div>
        </div>
      </section>
    </main>







@endsection
