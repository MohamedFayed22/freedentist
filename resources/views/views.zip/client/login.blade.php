@extends('frontend.app')

@section('content')
<main class="main-content">
      <!--login section-->
      <section class="login">
        <div class="title">
          <div class="container">
            <h2>@lang('login.cLogin')</h2>
          </div>
        </div>
		 <div class="container">
          <div class="content">
                    <form method="POST" action="{{ route('clientlogin') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">@lang('login.mobile')</label>

                            
                                <input id="mobile" type="text" class="form-control loginInput @error('mobile') is-invalid @enderror" name="mobile" value="{{ old('mobile') }}" required autocomplete="mobile" autofocus>

                                @error('mobile')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">@lang('login.password')</label>


                                <input id="password" type="password" class="form-control loginInput @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        
                        
                        <div class="form-group row ">
                               <button type="submit" class="btn btn-primary">
                                    @lang('login.login')
                                </button>
</div>
<div class="form-group form-group-flex">
                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                     @lang('login.forget')   
                                    </a>
                                @endif
								<a class="loginA" href="{{ route('clientRegister') }}">  @lang('login.register')  </a>
								</div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
