

<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
    <tr>
      <td class="text-services" style="text-align: left; padding: 20px 30px;">
          <div class="heading-section">
          <h2 style="font-size: 22px;">تغيير كلمة المرور</h2>
          <p>لقد تمت تغير كلمة المرور {{$data->message}}.</p>
          
          </div>
      </td>
    </tr>
  </table>
